# addtool
usage: ./addtool \<filename\>